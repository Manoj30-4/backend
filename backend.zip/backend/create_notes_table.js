require('dotenv').config();
const { DynamoDBClient, CreateTableCommand } = require('@aws-sdk/client-dynamodb');

const client = new DynamoDBClient({ region: process.env.AWS_REGION || 'ap-south-1' });

const params = {
  TableName: 'Notes',
  KeySchema: [
    { AttributeName: 'noteId', KeyType: 'HASH' } // Partition key
  ],
  AttributeDefinitions: [
    { AttributeName: 'noteId', AttributeType: 'S' },
    { AttributeName: 'userEmail', AttributeType: 'S' }
  ],
  GlobalSecondaryIndexes: [
    {
      IndexName: 'userEmail-index',
      KeySchema: [
        { AttributeName: 'userEmail', KeyType: 'HASH' }
      ],
      Projection: { ProjectionType: 'ALL' },
      BillingMode: 'PAY_PER_REQUEST'
    }
  ],
  BillingMode: 'PAY_PER_REQUEST' // On-demand pricing
};

async function createTable() {
  try {
    const data = await client.send(new CreateTableCommand(params));
    console.log('Notes table created successfully:', data.TableDescription.TableName);
  } catch (err) {
    console.error('Error creating table:', err);
  }
}

createTable();

require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const { DynamoDBClient, CreateTableCommand, DescribeTableCommand } = require('@aws-sdk/client-dynamodb');

const authRoutes = require('./routes/auth');
const notesRoutes = require('./routes/notes');

const app = express();
const dynamo = new DynamoDBClient({ region: process.env.AWS_REGION || 'ap-south-1' });

// Function to create tables if they don't exist
async function ensureTablesExist() {
  const usersTable = process.env.USERS_TABLE || 'Users';
  const notesTable = process.env.NOTES_TABLE || 'Notes';

  try {
    // Check if Users table exists
    await dynamo.send(new DescribeTableCommand({ TableName: usersTable }));
    console.log(`Table ${usersTable} already exists`);
  } catch (err) {
    if (err.name === 'ResourceNotFoundException') {
      console.log(`Creating table ${usersTable}...`);
      await dynamo.send(new CreateTableCommand({
        TableName: usersTable,
        KeySchema: [{ AttributeName: 'email', KeyType: 'HASH' }],
        AttributeDefinitions: [{ AttributeName: 'email', AttributeType: 'S' }],
        BillingMode: 'PAY_PER_REQUEST'
      }));
      console.log(`Table ${usersTable} created successfully`);
    } else {
      console.error(`Error checking table ${usersTable}:`, err);
    }
  }

  try {
    // Check if Notes table exists
    await dynamo.send(new DescribeTableCommand({ TableName: notesTable }));
    console.log(`Table ${notesTable} already exists`);
  } catch (err) {
    if (err.name === 'ResourceNotFoundException') {
      console.log(`Creating table ${notesTable}...`);
      await dynamo.send(new CreateTableCommand({
        TableName: notesTable,
        KeySchema: [{ AttributeName: 'noteId', KeyType: 'HASH' }],
        AttributeDefinitions: [
          { AttributeName: 'noteId', AttributeType: 'S' },
          { AttributeName: 'userEmail', AttributeType: 'S' }
        ],
        GlobalSecondaryIndexes: [{
          IndexName: 'userEmail-index',
          KeySchema: [{ AttributeName: 'userEmail', KeyType: 'HASH' }],
          Projection: { ProjectionType: 'ALL' },
          BillingMode: 'PAY_PER_REQUEST'
        }],
        BillingMode: 'PAY_PER_REQUEST'
      }));
      console.log(`Table ${notesTable} created successfully`);
    } else {
      console.error(`Error checking table ${notesTable}:`, err);
    }
  }
}
app.use(cors({
  origin: process.env.NODE_ENV === 'production'
    ? ['http://cloudnotes-app-frontend.s3-website-ap-south-1.amazonaws.com', 'https://yourdomain.com']
    : ['http://localhost:3000', 'http://127.0.0.1:3000', 'http://localhost:8080', 'http://127.0.0.1:5500'],
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));
app.use(bodyParser.json({ limit: '10mb' }));

app.get('/', (req,res)=> res.send('CloudNotes backend running'));

app.use('/auth', authRoutes);
app.use('/notes', notesRoutes);

// Ensure tables exist before starting server
ensureTablesExist().then(() => {
  const PORT = process.env.PORT || 3000;
  app.listen(PORT, () => console.log('Server listening on', PORT));
}).catch(err => {
  console.error('Failed to ensure tables exist:', err);
  process.exit(1);
});

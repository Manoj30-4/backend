require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const path = require('path');
const multer = require('multer');

const authRoutes = require('./routes/auth');
const notesRoutes = require('./routes/notes');

const app = express();
app.use(cors({
  origin: process.env.NODE_ENV === 'production'
    ? ['http://cloudnotes-app-frontend.s3-website-us-east-1.amazonaws.com', 'https://yourdomain.com']
    : ['http://localhost:3000', 'http://127.0.0.1:3000'],
  credentials: true
}));
app.use(bodyParser.json({ limit: '10mb' }));

if(process.env.SERVE_FRONTEND === '1'){
  app.get('/', (req,res)=> res.sendFile(path.join(__dirname, '..', 'frontend', 'index.html')));
} else {
  app.get('/', (req,res)=> res.send('CloudNotes backend running'));
}

app.use('/auth', authRoutes);
app.use('/notes', notesRoutes);

// optional static to serve frontend from the same server (if you choose)
if(process.env.SERVE_FRONTEND === '1'){
  app.use(express.static(path.join(__dirname, '..', 'frontend')));
  app.get('*', (req,res)=> {
    if(req.path.startsWith('/auth') || req.path.startsWith('/notes')) return next();
    res.sendFile(path.join(__dirname, '..', 'frontend', 'index.html'));
  });
}

const PORT = process.env.PORT || 3000;
app.listen(PORT, ()=> console.log('Server listening on', PORT));

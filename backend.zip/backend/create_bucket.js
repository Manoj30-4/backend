require('dotenv').config();
const { S3Client, CreateBucketCommand } = require('@aws-sdk/client-s3');

const s3 = new S3Client({ region: process.env.AWS_REGION || 'ap-south-1' });

async function createBucket() {
  const bucketName = process.env.UPLOAD_BUCKET || 'cloudnotes-app-uploads';
  try {
    await s3.send(new CreateBucketCommand({ Bucket: bucketName }));
    console.log(`Bucket '${bucketName}' created successfully`);
  } catch (e) {
    if (e.name === 'BucketAlreadyExists') {
      console.log(`Bucket '${bucketName}' already exists`);
    } else {
      console.error('Error creating bucket:', e.message);
    }
  }
}

createBucket();

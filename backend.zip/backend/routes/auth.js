const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { GetCommand, PutCommand } = require('@aws-sdk/lib-dynamodb');
const { ddbDoc } = require('../lib/aws');

const USERS_TABLE = process.env.USERS_TABLE || 'Users';
const JWT_SECRET = process.env.JWT_SECRET || 'supersecret';

router.post('/register', async (req,res)=>{
  try{
    const { email, password, name } = req.body;
    if(!email || !password) return res.status(400).json({ error: 'email and password required' });
    const existing = await ddbDoc.send(new GetCommand({ TableName: USERS_TABLE, Key: { email } }));
    if(existing.Item) return res.status(400).json({ error: 'User exists' });
    const hash = await bcrypt.hash(password, 10);
    const user = { email, name: name || '', password: hash, createdAt: new Date().toISOString() };
    await ddbDoc.send(new PutCommand({ TableName: USERS_TABLE, Item: user }));
    const token = jwt.sign({ email }, JWT_SECRET, { expiresIn: '7d' });
    res.json({ token, user: { email, name: user.name } });
  }catch(e){ console.error(e); res.status(500).json({ error: 'server error', details: e.message }); }
});

router.post('/login', async (req,res)=>{
  try{
    const { email, password } = req.body;
    if(!email || !password) return res.status(400).json({ error: 'email and password required' });
    const r = await ddbDoc.send(new GetCommand({ TableName: USERS_TABLE, Key: { email } }));
    if(!r.Item) return res.status(401).json({ error: 'invalid' });
    const ok = await bcrypt.compare(password, r.Item.password);
    if(!ok) return res.status(401).json({ error: 'invalid' });
    const token = jwt.sign({ email }, JWT_SECRET, { expiresIn: '7d' });
    res.json({ token, user: { email, name: r.Item.name || '' } });
  }catch(e){ console.error(e); res.status(500).json({ error: 'server error', details: e.message }); }
});

module.exports = router;

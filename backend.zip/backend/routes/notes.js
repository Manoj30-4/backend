const express = require('express');
const router = express.Router();
const multer = require('multer');
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 20 * 1024 * 1024 }});
const jwt = require('jsonwebtoken');
const { PutObjectCommand } = require('@aws-sdk/client-s3');
const { PutCommand, GetCommand, UpdateCommand, DeleteCommand, QueryCommand, ScanCommand } = require('@aws-sdk/lib-dynamodb');
const { s3, ddbDoc } = require('../lib_loader');
const { v4: uuidv4 } = require('uuid');
const { createWorker } = require('tesseract.js');

const NOTES_TABLE = process.env.NOTES_TABLE || 'Notes';
const BUCKET = process.env.UPLOAD_BUCKET || 'cloudnotes-app-uploads';
const JWT_SECRET = process.env.JWT_SECRET || 'supersecret';

function authMiddleware(req,res,next){
  const auth = req.headers.authorization;
  if(!auth) return res.status(401).json({error:'unauth'});
  const token = auth.split(' ')[1];
  try{
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  }catch(e){ res.status(401).json({error:'invalid token'}); }
}

router.post('/', authMiddleware, upload.array('files'), async (req,res)=>{
  try{
    const userEmail = req.user.email;
    const { title, description, tags } = req.body;
    const files = req.files || [];
    const noteId = uuidv4();
    const createdAt = new Date().toISOString();
    const images = [];

    for(const file of files){
      const key = `notes/${userEmail}/${noteId}/${Date.now()}_${file.originalname}`;
      await s3.send(new PutObjectCommand({
        Bucket: BUCKET,
        Key: key,
        Body: file.buffer,
        ContentType: file.mimetype
      }));
      // Tesseract.js - detect text from image
      let extractedText = '';
      try{
        console.log('Attempting Tesseract extraction for', file.originalname);
        const worker = await createWorker('eng');
        // Convert buffer to base64 for better compatibility
        const base64Image = file.buffer.toString('base64');
        const imageData = `data:${file.mimetype};base64,${base64Image}`;
        const { data: { text } } = await worker.recognize(imageData);
        await worker.terminate();
        extractedText = text.trim() || 'No readable text found in image';
        console.log('Tesseract extracted text length:', extractedText.length);
      }catch(err){
        console.warn('tesseract failed for', file.originalname, ':', err.message);
        extractedText = 'Text extraction failed - ' + err.message;
      }
      // public URL pattern (adjust if bucket is public)
      const publicUrl = `https://${BUCKET}.s3.amazonaws.com/${encodeURIComponent(key)}`;
      images.push({ filename: file.originalname, s3Key: key, publicUrl, extractedText });
    }

    const item = { noteId, userEmail, title, description: description||'', tags: tags ? tags.split(',').map(t=>t.trim()) : [], images, createdAt, updatedAt: createdAt };
    await ddbDoc.send(new PutCommand({ TableName: NOTES_TABLE, Item: item }));
    res.json({ note: item });
  }catch(e){ console.error(e); res.status(500).json({ error: 'server error', details: e.message }); }
});

router.get('/', authMiddleware, async (req,res)=>{
  const userEmail = req.user.email;
  const q = req.query.q || '';
  // Attempt to query by GSI userEmail-index otherwise scan
  try{
    const params = { TableName: process.env.NOTES_TABLE || NOTES_TABLE, IndexName: 'userEmail-index', KeyConditionExpression: 'userEmail = :ue', ExpressionAttributeValues: { ':ue': userEmail } };
    const r = await ddbDoc.send(new QueryCommand(params));
    let items = r.Items || [];
    // Filter by search query if provided
    if(q){
      const query = q.toLowerCase();
      items = items.filter(item =>
        (item.title && item.title.toLowerCase().includes(query)) ||
        (item.description && item.description.toLowerCase().includes(query)) ||
        (item.tags && item.tags.some(tag => tag.toLowerCase().includes(query)))
      );
    }
    res.json({ items });
  }catch(err){
    console.warn('Query failed, using scan fallback', err && err.message);
    const scanParams = { TableName: NOTES_TABLE };
    const r = await ddbDoc.send(new ScanCommand(scanParams));
    let items = r.Items || [];
    // Filter by user and search query
    items = items.filter(item => item.userEmail === userEmail);
    if(q){
      const query = q.toLowerCase();
      items = items.filter(item =>
        (item.title && item.title.toLowerCase().includes(query)) ||
        (item.description && item.description.toLowerCase().includes(query)) ||
        (item.tags && item.tags.some(tag => tag.toLowerCase().includes(query)))
      );
    }
    res.json({ items });
  }
});

router.get('/:id', authMiddleware, async (req,res)=>{
  const id = req.params.id;
  const r = await ddbDoc.send(new GetCommand({ TableName: NOTES_TABLE, Key: { noteId: id } }));
  if(!r.Item) return res.status(404).json({ error: 'not found' });
  res.json({ note: r.Item });
});

router.put('/:id', authMiddleware, async (req,res)=>{
  const id = req.params.id;
  const body = req.body;
  const update = {
    TableName: NOTES_TABLE,
    Key: { noteId: id },
    UpdateExpression: 'SET title=:t, description=:d, tags=:tags, updatedAt=:u',
    ExpressionAttributeValues: { ':t': body.title || '', ':d': body.description || '', ':tags': body.tags || [], ':u': new Date().toISOString() },
    ReturnValues: 'ALL_NEW'
  };
  const r = await ddbDoc.send(new UpdateCommand(update));
  res.json({ note: r.Attributes });
});

router.delete('/:id', authMiddleware, async (req,res)=>{
  const id = req.params.id;
  await ddbDoc.send(new DeleteCommand({ TableName: NOTES_TABLE, Key: { noteId: id } }));
  res.json({ ok: true });
});

module.exports = router;

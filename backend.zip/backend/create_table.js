require('dotenv').config();
const { DynamoDBClient, CreateTableCommand } = require('@aws-sdk/client-dynamodb');

const client = new DynamoDBClient({ region: process.env.AWS_REGION || 'ap-south-1' });

const params = {
  TableName: 'Users',
  KeySchema: [
    { AttributeName: 'email', KeyType: 'HASH' } // Partition key
  ],
  AttributeDefinitions: [
    { AttributeName: 'email', AttributeType: 'S' }
  ],
  BillingMode: 'PAY_PER_REQUEST' // On-demand pricing
};

async function createTable() {
  try {
    const data = await client.send(new CreateTableCommand(params));
    console.log('Table created successfully:', data.TableDescription.TableName);
  } catch (err) {
    console.error('Error creating table:', err);
  }
}

createTable();

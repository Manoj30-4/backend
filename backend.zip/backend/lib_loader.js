// small loader to avoid circular requires for aws exports
const { s3, ddbDoc, textract, PutObjectCommand, GetObjectCommand } = require('./lib/aws');
module.exports = { s3, ddbDoc, textract, PutObjectCommand, GetObjectCommand };
